// This is not really required, but means that changes to index.html will cause a reload.
require('./site/index.html');
// Apply the styles in style.css to the page.
require('./site/style.css');

global.DEBUG = false;

const client = Stomp.client("ws://localhost:8011/stomp");

client.debug = function (msg) {
  if (global.DEBUG) {
    console.info(msg)
  }
};

function connectCallback(message) {
  let currencyData = [];
  client.subscribe("/fx/prices", (message) => {
    let bidData = JSON.parse(message.body);
    let dataPointIndex = currencyData.map((e) => { return e.name; }).indexOf(bidData.name);
    if (dataPointIndex === -1) {
      bidData.sparklineData = [{"timeStamp": new Date().getTime(),"value": (bidData.bestBid + bidData.bestAsk)/2}];
      currencyData.push(bidData);
    } else {
      currencyData[dataPointIndex].sparklineData.push({"timeStamp": new Date().getTime(),"value": (bidData.bestBid + bidData.bestAsk)/2});
      bidData.sparklineData = currencyData[dataPointIndex].sparklineData;
      currencyData[dataPointIndex] = bidData;
    }
    currencyData.sort((a, b) => a.lastChangeBid - b.lastChangeBid);
    insertTableEntries(currencyData);
  });
};

function insertTableEntries(data) {
  document.querySelectorAll('tr:not(.header)').forEach((e) => { e.remove() })
  for(let i=0; i<data.length;i++) {
    let dataPoint = data[i];
    newItemTr = document.createElement("tr");
    newItemTr.innerHTML = "<td class='characterColumn'>" + dataPoint.name + "</td> <td class='numericColumn'>" + dataPoint.bestBid + "</td> <td class='numericColumn'>" + dataPoint.bestAsk + "</td> <td class='numericColumn'>" + dataPoint.lastChangeAsk + "</td> <td class='numericColumn'>" + dataPoint.lastChangeBid + "</td> <td id='sparkline"+ dataPoint.name +"'></td>";
    let headerElement = document.getElementById("dataTable").firstElementChild;
    headerElement.insertBefore(newItemTr, headerElement.childNodes[2]);
    Sparkline.draw(document.getElementById("sparkline"+ dataPoint.name), updateSparklineDataPoints(dataPoint));
  }
};


function updateSparklineDataPoints(data) {
  data.sparklineData = data.sparklineData.filter((obj) => {
    return obj.timeStamp >= new Date(Date.now() - 30000).getTime();
  });
  return data.sparklineData.map((obj) => {
    return obj.value;
  });
};


client.connect({}, connectCallback, (error) => {
  alert(error.headers.message)
});